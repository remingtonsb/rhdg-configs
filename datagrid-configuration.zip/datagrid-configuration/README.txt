####Instructions####
Copy all files to PVC in /opt/datagrid/standalone/configuration
